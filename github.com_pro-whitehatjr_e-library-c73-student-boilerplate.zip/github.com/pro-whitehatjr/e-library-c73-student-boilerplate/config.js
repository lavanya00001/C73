import firebase from "firebase"


const firebaseConfig={
  apiKey: "AIzaSyCtF62gf3fCYICjoLsovJ0PWt_vRtQ7o1o",
  authDomain: "class-71-affd6.firebaseapp.com",
  projectId: "class-71-affd6",
  storageBucket: "class-71-affd6.appspot.com",
  messagingSenderId: "869002433292",
  appId: "1:869002433292:web:6bca61240d4c64c7d26f29",
  measurementId: "G-QSXXR407EW"

}
if(!firebase.apps.length)
{firebase.initializeApp(firebaseConfig)}

export default firebase.firestore()